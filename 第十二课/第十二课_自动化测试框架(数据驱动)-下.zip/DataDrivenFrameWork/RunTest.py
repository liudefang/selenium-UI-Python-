# -*- encoding: utf-8 -*-
# @Time    : 2018/8/31 15:13
# @Author  : mike.liu
# @File    : RunTest.py
from testScripts.TestAddCustomer import TestAddCustomer

if __name__ == '__main__':
    TestAddCustomer()